[ ](/account/login/)

[](https://fandelmate.mitiendanube.com)

# Fan del Mate

¡Hola! [Iniciá sesión](/account/login/)

[O podés registrarte](/account/register)

0

() 

x  ****

**¡Agregado al carrito!**

[ Categorías ](/productos/)

  * [ Mates ](https://fandelmate.mitiendanube.com/mates/)
  * [ Termos ](https://fandelmate.mitiendanube.com/termos/)
  * [ Bombillas ](https://fandelmate.mitiendanube.com/bombillas/)
  * [ Canastas Materas ](https://fandelmate.mitiendanube.com/canastas-materas/)
  * [ Bolsos Materos ](https://fandelmate.mitiendanube.com/bolsos-materos/)
  * [ Yerbas y Blends ](https://fandelmate.mitiendanube.com/yerbas-y-blends/)
  * [ Accesorios ](https://fandelmate.mitiendanube.com/accesorios/)
  * [ Botellas Térmicas ](https://fandelmate.mitiendanube.com/botellas-termicas/)
  * [ Vasos Térmicos ](https://fandelmate.mitiendanube.com/vasos-termicos/)
  * [ Autocebantes/MateListos ](https://fandelmate.mitiendanube.com/autocebantes-matelistos/)
  * [ Yerberas ](https://fandelmate.mitiendanube.com/yerberas/)



  * [Inicio](/)
  * [Productos ](https://fandelmate.mitiendanube.com/productos/)

    * [Mates](https://fandelmate.mitiendanube.com/mates/)
    * [Termos](https://fandelmate.mitiendanube.com/termos/)
    * [Bombillas](https://fandelmate.mitiendanube.com/bombillas/)
    * [Canastas Materas](https://fandelmate.mitiendanube.com/canastas-materas/)
    * [Bolsos Materos](https://fandelmate.mitiendanube.com/bolsos-materos/)
    * [Yerbas y Blends](https://fandelmate.mitiendanube.com/yerbas-y-blends/)
    * [Accesorios](https://fandelmate.mitiendanube.com/accesorios/)
    * [Botellas Térmicas](https://fandelmate.mitiendanube.com/botellas-termicas/)
    * [Vasos Térmicos](https://fandelmate.mitiendanube.com/vasos-termicos/)
    * [Autocebantes/MateListos](https://fandelmate.mitiendanube.com/autocebantes-matelistos/)
    * [Yerberas](https://fandelmate.mitiendanube.com/yerberas/)

  * [ 54 9 11 7356-3617](/contacto/)



Al navegar por este sitio **aceptás el uso de cookies** para agilizar tu experiencia de compra. 

Entendido

¡Descuento exclusivo! 

  * [Inicio](/)
  * Productos 

Productos 

    * [ Ver todos los productos ](https://fandelmate.mitiendanube.com/productos/)
    * [Mates](https://fandelmate.mitiendanube.com/mates/)
    * [Termos](https://fandelmate.mitiendanube.com/termos/)
    * [Bombillas](https://fandelmate.mitiendanube.com/bombillas/)
    * [Canastas Materas](https://fandelmate.mitiendanube.com/canastas-materas/)
    * [Bolsos Materos](https://fandelmate.mitiendanube.com/bolsos-materos/)
    * [Yerbas y Blends](https://fandelmate.mitiendanube.com/yerbas-y-blends/)
    * [Accesorios](https://fandelmate.mitiendanube.com/accesorios/)
    * [Botellas Térmicas](https://fandelmate.mitiendanube.com/botellas-termicas/)
    * [Vasos Térmicos](https://fandelmate.mitiendanube.com/vasos-termicos/)
    * [Autocebantes/MateListos](https://fandelmate.mitiendanube.com/autocebantes-matelistos/)
    * [Yerberas](https://fandelmate.mitiendanube.com/yerberas/)

  * [ 54 9 11 7356-3617](/contacto/)



[Iniciar sesión](/account/login/) /[Crear cuenta](/account/register)

Carrito de compras 

El carrito de compras está vacío. 

¡Uy! No tenemos más stock de este producto para agregarlo al carrito. Si querés podés[ver otros acá](/productos/)

ARS

Subtotal:  $0,00

Descuento en todos los productos comprando o más

Descuento del cupón:

Descuento del cupón:

Total: $0,00

Total: $0,00 

O hasta 1 cuotas de  $0,00

El monto mínimo de compra es de $0,00 sin incluir el costo de envío. 

Ver más productos

¡Agregado al carrito! 

() 

x  ****

**Total** ( 0  productos):  producto):  **$0,00**

Ver carrito

### Envíos a todo el país 

Envíos Flex / Correo Argentino 

## Bienvenidos a Fan del Mate! 

Mirá nuestro catálogo completo: Mates, termos, yerberas, bombillas, bolsos y todo lo que necesitas para armar tu equipo ideal. Encontrá el tuyo y pedilo hoy!

[](https://fandelmate.mitiendanube.com/mates/)

## Como nació Fan del Mate

Fan del Mate nació en 2021 con una idea simple y una ilusión enorme: Que cada persona encuentre su equipo de mate soñado. Porque el mate es un ritual, una compañía, una forma de ser cada día; y cada uno lo vive a su manera: solo o en ronda, en casa, en el trabajo, en la ruta, tranquilo o a las corridas. En Fan del Mate te ayudamos a encontrar el equipo de mate que te representa, el que te es práctico, el que siempre quisiste tener. ¡El mejor equipo de mate para vos está acá!

[]()

[ ](https://wa.me/541173563617)

[ ](https://instagram.com/fandelmateba)

Categorías

  * [Inicio](/)
  * [Productos](https://fandelmate.mitiendanube.com/productos/)
  * [ 54 9 11 7356-3617](/contacto/)



Contactános

  * [ 541173563617 ](https://wa.me/541173563617)
  * [ +54 9 11 7356-3617 ](tel:+54 9 11 7356-3617)
  * Mendoza 2491 - Belgrano - CABA 



Newsletter

No completar este campo

Copyright Fan del Mate - 27256378812 - 2026. Todos los derechos reservados. 

Defensa de las y los consumidores. Para reclamos [ingresá acá.](https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario) / [Botón de arrepentimiento](/contacto/?order_cancellation_without_id=true)

[](https://www.tiendanube.com?utm_source=fandelmate.mitiendanube.com&utm_medium=referral&utm_campaign=footerSlogan "Tiendanube")