---
name: Fan del Mate E-Commerce
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadad9'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f3'
  surface-container: '#eeeeed'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#3e4948'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f0'
  outline: '#6e7978'
  outline-variant: '#bdc9c8'
  surface-tint: '#006a67'
  primary: '#006765'
  on-primary: '#ffffff'
  primary-container: '#0b827f'
  on-primary-container: '#f3fffd'
  inverse-primary: '#77d6d2'
  secondary: '#006a67'
  on-secondary: '#ffffff'
  secondary-container: '#85f5f0'
  on-secondary-container: '#00706e'
  tertiary: '#515e5e'
  on-tertiary: '#ffffff'
  tertiary-container: '#6a7777'
  on-tertiary-container: '#f3fffe'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#94f3ee'
  primary-fixed-dim: '#77d6d2'
  on-primary-fixed: '#00201f'
  on-primary-fixed-variant: '#00504e'
  secondary-fixed: '#85f5f0'
  secondary-fixed-dim: '#67d8d3'
  on-secondary-fixed: '#00201f'
  on-secondary-fixed-variant: '#00504e'
  tertiary-fixed: '#d7e5e4'
  tertiary-fixed-dim: '#bbc9c8'
  on-tertiary-fixed: '#111e1d'
  on-tertiary-fixed-variant: '#3c4949'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  price-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 34px
    letterSpacing: -0.01em
  price-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-3xs: 0.125rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  space-4xl: 6rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  container-max: 80rem
---

## Brand & Style

This design system establishes a warm, contemporary, and premium e-commerce experience dedicated to the ritual of mate. It blends an inviting, artisanal cultural identity with clean Scandinavian-inspired minimalism: pure white negative space, crisp deep charcoal typography, and vibrant teal and turquoise accents derived directly from the brand’s emblematic logo mark.

### Audience & Mood
- **Target Audience:** Contemporary mate enthusiasts across Argentina looking for premium handcrafted gourds (imperial, camionero, torpedo), surgical-grade stainless steel bombillas, vacuum-insulated thermoses, curated starter sets, and custom leather accessories.
- **Emotional Response:** Comfort, pride in ritual, tactile craftsmanship, trustworthiness, and effortless purchase navigation.
- **Style Direction:** Modern Clean Commerce with Warm Tactile Touches. Pure white canvases allow natural calabash textures, hand-chiseled alpaca metalwork, and rich cowhide leathers to stand out without competing chrome or visual noise.

## Colors

The palette is engineered around high optical contrast and vibrant turquoise energy against crisp neutral white:

- **Primary (`#1F8B88`):** Deep brand teal drawn from the brand logo mark. Applied to primary call-to-actions, prominent badges, category active states, and focused boundaries.
- **Secondary (`#2CA8A4`):** Bright turquoise for interactive hover transitions, micro-interaction states, and sale highlights.
- **Tertiary (`#E6F4F3`):** Soft mist teal tinted surface background used for badge containers, soft pill filters, and subtle promo callout cards.
- **Neutral (`#181A1A`):** Deep graphite black for high-legibility typography, clear pricing in $ ARS, and precise framing lines.
- **Surface Neutrals:** Pure canvas white (`#FFFFFF`) for the global page backdrop, accompanied by a subtle slate divider tone (`#F3F5F5` and `#E2E8E8`) to frame modular product cards and checkout steps without visual clutter.

## Typography

The design system relies entirely on `Plus Jakarta Sans` across display, body, and UI labels. Its geometric precision and generous open counters ensure immediate legibility while carrying rounded, human curves that reflect the artisanal mate warmth.

- **Numerals & ARS Pricing:** Formatted with tabular, bold weight figures (`price-lg` and `price-md`), highlighting payment installments (e.g., *3 cuotas sin interés de $...*) with crisp secondary notes.
- **Hierarchy Rules:** All product cards prioritize product title at `headline-sm`, retail price at `price-md`, and installment badges at `label-md`. Display titles use tight negative tracking (`-0.02em`) to deliver modern storefront impact.

## Layout & Spacing

A disciplined 8-point layout rhythm structures all modular grids:

- **Desktop (>=1024px):** 12-column grid within a max-width container of `80rem` (1280px), centered with `gutter-desktop` (24px). Product catalogs render in 4-column cards with `space-lg` (24px) gutters.
- **Tablet (768px - 1023px):** 8-column grid with `space-md` (16px) margins, presenting product catalogs in 3 or 2-column configurations.
- **Mobile (<768px):** 4-column fluid layout with `gutter-mobile` (16px) side margins and 2-column compact product grids.
- **White Space Philosophy:** Generous vertical section padding (`space-3xl` to `space-4xl`) guarantees clean breathability, emphasizing the immaculate pure white studio backgrounds of mate photography.

## Elevation & Depth

Visual hierarchy uses delicate low-contrast outlines supplemented by soft, diffused teal-tinted ambient shadows. Avoid heavy dark shadows to protect the luminous, clean white atmosphere.

- **Level 0 (Flat):** Pure `#FFFFFF` canvas with hairline boundary strokes (`#EAEFEF`, 1px).
- **Level 1 (Card Rest):** Subtly outlined with `#E2EBEA`, combined with an ambient whisper shadow: `0 4px 16px -2px rgba(31, 139, 136, 0.05)`.
- **Level 2 (Hover & Popover):** Elevated on user interaction with a turquoise glow-lift: `0 12px 28px -4px rgba(31, 139, 136, 0.12)`.
- **Level 3 (Sticky Header, Cart Drawer & Modal):** `0 20px 40px -8px rgba(24, 26, 26, 0.14)`, grounding floating elements over subtle white translucent backdrops (`backdrop-filter: blur(12px)`).

## Shapes

The shape system embraces warm curvature, mirroring the organic contours of calabash gourds and curved bombillas.

- **Base Corner Radius (`rounded-md`):** `0.5rem` (8px) used for text inputs, form controls, and secondary buttons.
- **Container Radius (`rounded-lg`):** `1rem` (16px) for product cards, quick-view sheets, coupon wrappers, and cart summaries.
- **Pill Radius (`rounded-full`):** Completely rounded (9999px) for category chips, promotional badges (*"Cuotas sin interés"*, *"Envío gratis"*), counter pills, and floating action triggers.

## Components

### Buttons
- **Primary Button:** Background `#1F8B88`, text `#FFFFFF`, font `label-lg`, height `48px`, border-radius `0.75rem`. Hover transitions to `#2CA8A4` with a subtle elevation shift (`translateY(-1px)`).
- **Secondary / Outline Button:** Border `1.5px solid #1F8B88`, background transparent, text `#1F8B88`. Hover transitions to background `#E6F4F3`.
- **Quick Add / Icon Button:** Circular `40px` or `48px` pill with smooth teal micro-scale animation when adding mates or bombillas to the cart.

### Product Cards
- Contained in a crisp white tile (`#FFFFFF`) framed by a soft `1px solid #EAEFEF` border and `1rem` radius.
- Image container features 1:1 aspect ratio with an ultra-subtle off-white background (`#F9FBFA`).
- Includes floating tag overlays at the top left (e.g., *"Calabaza Brasilera"*, *"Alpaca Cincelada"*, *"Envío Gratis"*) rendered in pill badges.
- Pricing block highlights main amount in `price-md` (`#181A1A`) and payment terms in `#1F8B88` (`body-sm` font weight `600`).

### Filter Chips & Tags
- Height `36px`, pill shape.
- **Default:** Background `#FFFFFF`, border `1px solid #D5E2E1`, text `#181A1A`.
- **Active / Selected:** Background `#1F8B88`, border `1px solid #1F8B88`, text `#FFFFFF`, accompanied by smooth ripple feedback.

### Form Inputs & Quantities
- Inputs feature `48px` height, `0.5rem` radius, crisp `1px solid #D9E3E2` borders, and placeholder text in `#7E8A89`.
- **Focus State:** Rings `#1F8B88` border with a 3px soft outer ring in `rgba(31, 139, 136, 0.18)`.
- **Quantity Selector:** Pill-shaped grouped control with `#E6F4F3` background and `#1F8B88` interactive minus/plus icons.

### Checkboxes & Radios
- `20px` sizing with `6px` radius (checkbox) or circular (radio). Unchecked state uses a `1.5px` border in `#BCCBC9`. Active state fills `#1F8B88` with a crisp white icon.

### Specialized E-Commerce Modules
- **Cart Slide-Over Drawer:** Displays free shipping threshold progress bar filled with `#2CA8A4` on a `#E6F4F3` track.
- **Installment Calculator Modal:** Clean breakdown table for Argentine debit/credit card schemes (Cuota Simple, transfer discounts) highlighted in brand teal accents.